package com.order.service.management.service.Impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.order.service.management.constants.ExceptionConstants;
import com.order.service.management.entity.Order;
import com.order.service.management.entity.OrderServiceItem;
import com.order.service.management.exceptions.BaseException;
import com.order.service.management.feignclient.OrderItemsServiceFeignClient;
import com.order.service.management.model.CommonUtils;
import com.order.service.management.model.OrderItemsDto;
import com.order.service.management.model.OrderDto;
import com.order.service.management.model.StatusVo;
import com.order.service.management.repository.OrderRepository;
import com.order.service.management.service.orderService;

@Service
public class OrderServiceImpl implements orderService {

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OrderItemsServiceFeignClient orderItemsServiceFeignClient;

	@Override
	@Transactional
	public StatusVo saveOrder(OrderDto orderDto) {
		StatusVo statusVo = new StatusVo();
		ResponseEntity<List<OrderItemsDto>> itemsDtos = orderItemsServiceFeignClient
				.OrderedItems("application/json", "Anil");
		List<OrderItemsDto> orderItemsDto = new ArrayList<OrderItemsDto>();

		for (OrderItemsDto oid : itemsDtos.getBody()) {
			orderItemsDto.add(oid);
		}
		if (Objects.nonNull(orderDto)) {
			Order order = new Order();
			order.setCustomerName(orderDto.getCustomerName());
			order.setOrderDate(orderDto.getOrderDate());
			order.setShippingAddress(orderDto.getShippingAddress());
			order.setTotal(orderDto.getTotal());
			order = orderRepository.save(order);
			statusVo.setKey(order.getOrderId());
			statusVo.setStatus(CommonUtils.SUCCESS);

			OrderServiceItem orderServiceItem = new OrderServiceItem();
			orderServiceItem.setOrderItemId(itemsDtos.getBody().iterator()
					.next().getOrderItemId());
			orderServiceItem.setOrderId(order.getOrderId());
			return statusVo;
		}
		throw new BaseException(ExceptionConstants.ORDER_SAVE,
				ExceptionConstants.ORDER_SERVICE_MANAGMENT);
	}

	@Override
	public List<OrderDto> orders() {
		List<OrderDto> orders = new ArrayList<OrderDto>();
		orders = orderRepository.Orders();
		if (Objects.isNull(orders)) {
			throw new BaseException(ExceptionConstants.ORDERS_NOT_FOUND,
					ExceptionConstants.ORDER_SERVICE_MANAGMENT);
		}
		return orders;
	}

}
