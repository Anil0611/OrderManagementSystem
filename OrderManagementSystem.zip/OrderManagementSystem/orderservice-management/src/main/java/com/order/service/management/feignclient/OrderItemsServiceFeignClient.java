package com.order.service.management.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;

import com.order.service.management.model.OrderItemsDto;

@FeignClient(name = "orderItem-management", url = "localhost:8085")
@RequestMapping(path = "/orderItems")
public interface OrderItemsServiceFeignClient {

	@GetMapping(path = "")
	public ResponseEntity<List<OrderItemsDto>> OrderedItems(
			@RequestHeader(value = "Accept") String acceptHeader,
			@RequestHeader(value = "Authorization") String authorizationHeader);
}