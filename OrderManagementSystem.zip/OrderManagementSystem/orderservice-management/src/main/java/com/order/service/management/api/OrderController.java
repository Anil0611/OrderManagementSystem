package com.order.service.management.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.service.management.model.OrderDto;
import com.order.service.management.model.StatusVo;
import com.order.service.management.service.orderService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "/orders", description = "orders creation and retrieval")
@RestController
@RequestMapping(path = "/orders")
@CrossOrigin(maxAge = 3600, origins = "*")
public class OrderController {

	@Autowired
	private orderService orderService;

	@ApiOperation(value = "Save Order Items")
	@PostMapping(path = "", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> saveOrder(
			@RequestHeader(value = "Accept") String acceptHeader,
			@RequestHeader(value = "Authorization") String authorizationHeader,
			@RequestBody OrderDto orderDto) {
		boolean validate = validate(acceptHeader, authorizationHeader);
		if (validate == true) {
			StatusVo standardResponse = new StatusVo();
			if (standardResponse != null) {
				standardResponse = orderService.saveOrder(orderDto);
				return new ResponseEntity<>(standardResponse,
						HttpStatus.CREATED);
			}
		}
		return new ResponseEntity<>("unathorized Access",
				HttpStatus.UNAUTHORIZED);
	}

	@ApiOperation(value = "Returns the results of order")
	@GetMapping(path = "", produces = "application/json")
	public ResponseEntity<Object> OrderedItems(
			@RequestHeader(value = "Accept") String acceptHeader,
			@RequestHeader(value = "Authorization") String authorizationHeader) {
		List<OrderDto> standardResponse = new ArrayList<OrderDto>();
		boolean validate = validate(acceptHeader, authorizationHeader);
		if (validate == true) {
			standardResponse = orderService.orders();
			if (!standardResponse.isEmpty()) {
				return new ResponseEntity<>(standardResponse, HttpStatus.OK);
			}
			return new ResponseEntity<>("data not_found", HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<>("unathorized-Access",
					HttpStatus.UNAUTHORIZED);
		}

	}

	public Boolean validate(String acceptHeader, String authorizationHeader) {
		Map<String, String> returnValue = new HashMap<>();
		returnValue.put("Accept", acceptHeader);
		returnValue.put("Authorization", authorizationHeader);
		for (Map.Entry<String, String> entry : returnValue.entrySet()) {
			if (entry.getKey().equalsIgnoreCase("Authorization")
					&& entry.getValue().equalsIgnoreCase("Anil")) {
				return true;
			}

		}
		return false;

	}

}
