package com.order.service.management.service;

import java.util.List;

import com.order.service.management.model.OrderDto;
import com.order.service.management.model.StatusVo;

public interface orderService {

	StatusVo saveOrder(OrderDto orderDto);

	List<OrderDto> orders();

}
